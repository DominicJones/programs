#ifndef _parms_compilerflags_h_
#define _parms_compilerflags_h_

#ifndef USE_MPI
#define USE_MPI
#endif

#ifndef REAL
#define REAL double
#endif

#ifndef DBL
#define DBL
#endif

#ifndef HAS_BLAS
#define HAS_BLAS
#endif

#ifndef FORTRAN_UNDERSCORE
#define FORTRAN_UNDERSCORE
#endif

#ifndef VOID_POINTER_SIZE_8
#define VOID_POINTER_SIZE_8
#endif

#endif
