#ifdef VOID_POINTER_SIZE_4
#define fprm integer*4
#elif defined(VOID_POINTER_SIZE_8)
#define fprm integer*8
#endif
